export const LoadingState = ({ message }: { message: string }) => {
  return (
    <div className="loading-state" role="status" aria-live="polite">
      <span className="loading-state__dot" aria-hidden="true" />
      <p>{message}</p>
    </div>
  )
}
