import { useEffect } from 'react'

interface ToastProps {
  message: string
  tone: 'success' | 'warning' | 'danger' | 'neutral'
  onClose: () => void
}

export const Toast = ({ message, tone, onClose }: ToastProps) => {
  useEffect(() => {
    const timeout = window.setTimeout(onClose, 2500)
    return () => window.clearTimeout(timeout)
  }, [onClose])

  return (
    <div className={`toast toast--${tone}`} role="status">
      <p>{message}</p>
      <button type="button" onClick={onClose} aria-label="بستن پیام">
        ×
      </button>
    </div>
  )
}
