import type { ReactNode } from 'react'

interface StatCardProps {
  label: string
  value: string | number
  hint?: string
  icon?: ReactNode
}

export const StatCard = ({ label, value, hint, icon }: StatCardProps) => {
  return (
    <article className="stat-card">
      <div className="stat-card__label">{label}</div>
      <div className="stat-card__row">
        <strong className="stat-card__value">{value}</strong>
        {icon}
      </div>
      {hint && <p className="stat-card__hint">{hint}</p>}
    </article>
  )
}
