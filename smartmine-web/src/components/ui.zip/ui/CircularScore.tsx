interface CircularScoreProps {
  score: number
}

export const CircularScore = ({ score }: CircularScoreProps) => {
  const radius = 54
  const circumference = 2 * Math.PI * radius
  const offset = circumference - (score / 100) * circumference

  return (
    <div className="circular-score" aria-label={`امتیاز ${score} از 100`}>
      <svg viewBox="0 0 140 140" role="img" aria-hidden="true">
        <circle cx="70" cy="70" r={radius} className="circular-score__track" />
        <circle
          cx="70"
          cy="70"
          r={radius}
          className="circular-score__value"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
        />
      </svg>
      <div className="circular-score__text">
        <strong>{score}</strong>
        <span>از 100</span>
      </div>
    </div>
  )
}
