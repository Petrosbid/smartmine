import type { ButtonHTMLAttributes, ReactNode } from 'react'

type ButtonVariant = 'primary' | 'ghost' | 'danger'

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant
  block?: boolean
  icon?: ReactNode
}

export const Button = ({
  variant = 'primary',
  block = false,
  icon,
  children,
  className,
  ...rest
}: ButtonProps) => {
  return (
    <button
      className={`btn btn--${variant} ${block ? 'btn--block' : ''} ${className ?? ''}`}
      {...rest}
    >
      {icon}
      <span>{children}</span>
    </button>
  )
}
